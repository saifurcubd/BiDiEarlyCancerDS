package cancer.earlycancer.dao;

public interface EarlyCancerInterface {
	public void reset(); 
	public void defaultValues();
	public void binaryDetect();
	public void localDetect();
	public void systemRun();
	

}

package cancer.earlycancer.dao;

import cancer.earlycancer.model.EarlyCancer;

public class EarlyCancerDAO implements EarlyCancerInterface {
	
	public void cancerDataEntry(EarlyCancer earlyCancer) throws Exception{
		
	}

	public EarlyCancerDAO() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void defaultValues() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void binaryDetect() {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void localDetect() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void systemRun() {
		// TODO Auto-generated method stub
		
	}

}

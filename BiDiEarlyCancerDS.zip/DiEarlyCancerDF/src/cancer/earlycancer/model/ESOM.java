package cancer.earlycancer.model;

public class ESOM {

	public ESOM() {
		// TODO Auto-generated constructor stub
		System.out.println("ESOM method executing....");
		new SMOTE();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
}

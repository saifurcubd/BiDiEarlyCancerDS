package cancer.earlycancer.model;

public class bRFE {

	public bRFE() {
		// TODO Auto-generated constructor stub
		System.out.println("bRFE method executing....");
	}

}
